﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RobotikosPrograma
{
    public partial class Form2 : Form
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }

        //Issaugoti istekliu kiekius ir kitus duomenis
        private void Save_Btn_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked == false && MyConnection.type == "U")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IvestiIstekliai, IvestuIstekliuKiek, " +
                    "DataIvestu) VALUES (@VardasIrPavarde, @IvestiIstekliai, @IvestuIstekliuKiek, @DataIvestu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", Form1.SetValueForText1);
                cmd.Parameters.AddWithValue("@IvestiIstekliai", Prideti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IvestuIstekliuKiek", Prideti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIvestu", DataPridetu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai pridėta");
            }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && MyConnection.type == "U")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IsimtiIstekliai, IsimtuIstekliuKiek, " +
                    "DataIsimtu) VALUES (@VardasIrPavarde, @IsimtiIstekliai, @IsimtuIstekliuKiek, @DataIsimtu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", Form1.SetValueForText1);
                cmd.Parameters.AddWithValue("@IsimtiIstekliai", Isimti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IsimtuIstekliuKiek", Isimti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIsimtu", DataIsimtu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai išimta");
            }
            else if (checkBox1.Checked == true && checkBox2.Checked == false && MyConnection.type == "A" && NameLastName_txt.Text != "")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IvestiIstekliai, IvestuIstekliuKiek, " +
                    "DataIvestu) VALUES (@VardasIrPavarde, @IvestiIstekliai, @IvestuIstekliuKiek, @DataIvestu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", NameLastName_txt.Text);
                cmd.Parameters.AddWithValue("@IvestiIstekliai", Prideti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IvestuIstekliuKiek", Prideti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIvestu", DataPridetu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai pridėta");
            }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && MyConnection.type == "A" && NameLastName_txt.Text != "")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IsimtiIstekliai, IsimtuIstekliuKiek, " +
                    "DataIsimtu) VALUES (@VardasIrPavarde, @IsimtiIstekliai, @IsimtuIstekliuKiek, @DataIsimtu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", NameLastName_txt.Text);
                cmd.Parameters.AddWithValue("@IsimtiIstekliai", Isimti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IsimtuIstekliuKiek", Isimti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIsimtu", DataIsimtu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai išimta");
            }
            else if (checkBox1.Checked == true && checkBox2.Checked == false && MyConnection.type == "A" && NameLastName_txt.Text == "")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IvestiIstekliai, IvestuIstekliuKiek, " +
                    "DataIvestu) VALUES (@VardasIrPavarde, @IvestiIstekliai, @IvestuIstekliuKiek, @DataIvestu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", Form1.SetValueForText1);
                cmd.Parameters.AddWithValue("@IvestiIstekliai", Prideti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IvestuIstekliuKiek", Prideti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIvestu", DataPridetu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai pridėta");
            }
            else if (checkBox1.Checked == false && checkBox2.Checked == true && MyConnection.type == "A" && NameLastName_txt.Text == "")
            {
                con.Open();
                cmd = new SqlCommand("INSERT INTO Robotika (VardasIrPavarde, IsimtiIstekliai, IsimtuIstekliuKiek, " +
                    "DataIsimtu) VALUES (@VardasIrPavarde, @IsimtiIstekliai, @IsimtuIstekliuKiek, @DataIsimtu)", con);
                cmd.Parameters.AddWithValue("@VardasIrPavarde", Form1.SetValueForText1);
                cmd.Parameters.AddWithValue("@IsimtiIstekliai", Isimti_ComboBox.Text.ToString());
                cmd.Parameters.AddWithValue("@IsimtuIstekliuKiek", Isimti_TextBox.Text);
                cmd.Parameters.AddWithValue("@DataIsimtu", DataIsimtu.Value);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("sėkmingai išimta");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //tikrinti ar administratorius ir jei taip tai rodyti administratoriaus visus mygtukus, jei ne tai rodyti vartotojo mygtukus
            if (MyConnection.type == "A")
            {

                Prideti_ComboBox.Visible = false;
                Prideti_TextBox.Visible = false;
                Isimti_ComboBox.Visible = false;
                Isimti_TextBox.Visible = false;
                DataPridetu.Visible = false;
                DataIsimtu.Visible = false;
                label2.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;

                Save_Btn.Visible = true;
                Info_Btn.Visible = true;
                //Ataskaita_btn.Visible = true;
                Paieska_btn.Visible = true;
                NameLastName_txt.Visible = true;
                label1.Visible = true;

                addNewUsers_btn.Visible = true;
                button2.Visible = true;
            }
            else if (MyConnection.type == "U")
            {

                Prideti_ComboBox.Visible = false;
                Prideti_TextBox.Visible = false;
                Isimti_ComboBox.Visible = false;
                Isimti_TextBox.Visible = false;
                DataPridetu.Visible = false;
                DataIsimtu.Visible = false;
                label2.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;

                NameLastName_txt.Visible = false;
                label1.Visible = false;
                Save_Btn.Visible = true;
                Info_Btn.Visible = true;
                //Ataskaita_btn.Visible = true;
                Paieska_btn.Visible = true;


                addNewUsers_btn.Visible = false;
                button2.Visible = false;
            }
            Vardas_Pavarde_lbl.Text = Form1.SetValueForText1;

            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Istekliai", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();

            Isimti_ComboBox.DataSource = ds.Tables[0];
            Isimti_ComboBox.DisplayMember = "IsteklioPVD";
            Isimti_ComboBox.ValueMember = "Id";

            Prideti_ComboBox.DataSource = ds.Tables[0];
            Prideti_ComboBox.DisplayMember = "IsteklioPVD";
            Prideti_ComboBox.ValueMember = "Id";
            con.Close();

        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
        //pazymetas langelis atidaro tam tikrus mygtukus, arba jei nuzymi, juos paslepia
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                Prideti_ComboBox.Visible = true;
                Prideti_TextBox.Visible = true;
                DataPridetu.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
            }
            else if (checkBox1.Checked != true)
            {
                Prideti_ComboBox.Visible = false;
                Prideti_TextBox.Visible = false;
                DataPridetu.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
            }
            if (checkBox1.Checked == true)
                checkBox2.Checked = false;
        }
        //pazymetas langelis atidaro tam tikrus mygtukus, arba jei nuzymi, juos paslepia
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                Isimti_ComboBox.Visible = true;
                Isimti_TextBox.Visible = true;
                DataIsimtu.Visible = true;
                label2.Visible = true;
                label7.Visible = true;
            }
            else if (checkBox2.Checked != true)
            {
                Isimti_ComboBox.Visible = false;
                Isimti_TextBox.Visible = false;
                DataIsimtu.Visible = false;
                label2.Visible = false;
                label7.Visible = false;
            }
            if (checkBox2.Checked == true)
                checkBox1.Checked = false;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Ataskaita1_Click(object sender, EventArgs e)
        {
            Form6 d = new Form6();
            d.Show();
            this.Hide();
        }

        private void addNewUsers_btn_Click(object sender, EventArgs e)
        {
            //atidaro naujo vartotojo pridejimo langa
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //atidaro nauju istekliu pridejimo langa
            Form5 d = new Form5();
            d.Show();
            this.Hide();
        }

        private void Info_Btn_Click(object sender, EventArgs e)
        {
            //parodo informacija apie programos kureja
            MessageBox.Show("Robotikos laboratorijos techninių išteklių apskaitos ir valdymo programa, sukurta Panevėžio Juozo Balčikonio gimnazijos moksleivio Milano Rinkevičiaus " +
                "2021/22, kaip informatikos srities brandos darbas, skirta JBG Robotikos laboratorijos išteklių registravimui ir valdymui Kilus neaiškumams kreiptis " +
                "tel 860846958, arba el. paštu milanasrink@gmail.com");
        }

        private void Paieska_btn_Click(object sender, EventArgs e)
        {
            //atidaro paieskos langa
            Form7 L = new Form7();
            L.Show();
            this.Hide();
        }

        /*private void Ataskaita_btn_Click(object sender, EventArgs e)
        {

        }*/
    }
}
