﻿
namespace RobotikosPrograma
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.Ataskaita1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.NameLastName_txt = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Vardas_Pavarde_lbl = new System.Windows.Forms.Label();
            this.addNewUsers_btn = new System.Windows.Forms.Button();
            this.DataIsimtu = new System.Windows.Forms.DateTimePicker();
            this.DataPridetu = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Paieska_btn = new System.Windows.Forms.Button();
            this.Info_Btn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Prideti_TextBox = new System.Windows.Forms.TextBox();
            this.Save_Btn = new System.Windows.Forms.Button();
            this.Isimti_TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Isimti_ComboBox = new System.Windows.Forms.ComboBox();
            this.Prideti_ComboBox = new System.Windows.Forms.ComboBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Ataskaita1
            // 
            this.Ataskaita1.Location = new System.Drawing.Point(354, 261);
            this.Ataskaita1.Name = "Ataskaita1";
            this.Ataskaita1.Size = new System.Drawing.Size(79, 48);
            this.Ataskaita1.TabIndex = 53;
            this.Ataskaita1.Text = "Ataskaita pagal išteklius";
            this.Ataskaita1.UseVisualStyleBackColor = true;
            this.Ataskaita1.Click += new System.EventHandler(this.Ataskaita1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(354, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 52;
            this.label1.Text = "Vardas ir Pavardė";
            // 
            // NameLastName_txt
            // 
            this.NameLastName_txt.Location = new System.Drawing.Point(354, 69);
            this.NameLastName_txt.Name = "NameLastName_txt";
            this.NameLastName_txt.Size = new System.Drawing.Size(100, 20);
            this.NameLastName_txt.TabIndex = 51;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(439, 334);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 48);
            this.button2.TabIndex = 50;
            this.button2.Text = "Prideti išteklius";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Vardas_Pavarde_lbl
            // 
            this.Vardas_Pavarde_lbl.AutoSize = true;
            this.Vardas_Pavarde_lbl.Location = new System.Drawing.Point(35, 47);
            this.Vardas_Pavarde_lbl.Name = "Vardas_Pavarde_lbl";
            this.Vardas_Pavarde_lbl.Size = new System.Drawing.Size(0, 13);
            this.Vardas_Pavarde_lbl.TabIndex = 49;
            // 
            // addNewUsers_btn
            // 
            this.addNewUsers_btn.Location = new System.Drawing.Point(85, 334);
            this.addNewUsers_btn.Name = "addNewUsers_btn";
            this.addNewUsers_btn.Size = new System.Drawing.Size(100, 48);
            this.addNewUsers_btn.TabIndex = 48;
            this.addNewUsers_btn.Text = "Pridėti naujus vartotojus";
            this.addNewUsers_btn.UseVisualStyleBackColor = true;
            this.addNewUsers_btn.Click += new System.EventHandler(this.addNewUsers_btn_Click);
            // 
            // DataIsimtu
            // 
            this.DataIsimtu.Checked = false;
            this.DataIsimtu.Location = new System.Drawing.Point(466, 171);
            this.DataIsimtu.Name = "DataIsimtu";
            this.DataIsimtu.Size = new System.Drawing.Size(136, 20);
            this.DataIsimtu.TabIndex = 39;
            this.DataIsimtu.Value = new System.DateTime(2022, 3, 11, 12, 27, 28, 0);
            // 
            // DataPridetu
            // 
            this.DataPridetu.Checked = false;
            this.DataPridetu.Location = new System.Drawing.Point(466, 171);
            this.DataPridetu.Name = "DataPridetu";
            this.DataPridetu.Size = new System.Drawing.Size(136, 20);
            this.DataPridetu.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 13);
            this.label7.TabIndex = 46;
            this.label7.Text = "Išteklių pavadinimai";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 45;
            this.label6.Text = "Išteklių pavadinimai";
            // 
            // Paieska_btn
            // 
            this.Paieska_btn.Location = new System.Drawing.Point(523, 261);
            this.Paieska_btn.Name = "Paieska_btn";
            this.Paieska_btn.Size = new System.Drawing.Size(79, 45);
            this.Paieska_btn.TabIndex = 43;
            this.Paieska_btn.Text = "Paieška";
            this.Paieska_btn.UseVisualStyleBackColor = true;
            this.Paieska_btn.Click += new System.EventHandler(this.Paieska_btn_Click);
            // 
            // Info_Btn
            // 
            this.Info_Btn.Location = new System.Drawing.Point(178, 261);
            this.Info_Btn.Name = "Info_Btn";
            this.Info_Btn.Size = new System.Drawing.Size(79, 45);
            this.Info_Btn.TabIndex = 41;
            this.Info_Btn.Text = "INFO";
            this.Info_Btn.UseVisualStyleBackColor = true;
            this.Info_Btn.Click += new System.EventHandler(this.Info_Btn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(294, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 44;
            this.label5.Text = "Kiekis";
            // 
            // Prideti_TextBox
            // 
            this.Prideti_TextBox.Location = new System.Drawing.Point(262, 172);
            this.Prideti_TextBox.Name = "Prideti_TextBox";
            this.Prideti_TextBox.Size = new System.Drawing.Size(100, 20);
            this.Prideti_TextBox.TabIndex = 34;
            // 
            // Save_Btn
            // 
            this.Save_Btn.Location = new System.Drawing.Point(10, 261);
            this.Save_Btn.Name = "Save_Btn";
            this.Save_Btn.Size = new System.Drawing.Size(79, 45);
            this.Save_Btn.TabIndex = 40;
            this.Save_Btn.Text = "Išsaugoti";
            this.Save_Btn.UseVisualStyleBackColor = true;
            this.Save_Btn.Click += new System.EventHandler(this.Save_Btn_Click);
            // 
            // Isimti_TextBox
            // 
            this.Isimti_TextBox.Location = new System.Drawing.Point(262, 172);
            this.Isimti_TextBox.Name = "Isimti_TextBox";
            this.Isimti_TextBox.Size = new System.Drawing.Size(100, 20);
            this.Isimti_TextBox.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Kiekis";
            // 
            // Isimti_ComboBox
            // 
            this.Isimti_ComboBox.FormattingEnabled = true;
            this.Isimti_ComboBox.Items.AddRange(new object[] {
            "Jutikliniai moduliai",
            "Sąsaja su žmogaus moduliai",
            "Ratai",
            "Tranzistoriai",
            "Mikrovaldikliai",
            "Valdymo ir stiprinimo moduliai",
            "Varikliai",
            "Diodai",
            "LED",
            "Komunikacijos moduliai"});
            this.Isimti_ComboBox.Location = new System.Drawing.Point(34, 170);
            this.Isimti_ComboBox.Name = "Isimti_ComboBox";
            this.Isimti_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.Isimti_ComboBox.TabIndex = 35;
            // 
            // Prideti_ComboBox
            // 
            this.Prideti_ComboBox.FormattingEnabled = true;
            this.Prideti_ComboBox.Items.AddRange(new object[] {
            "Jutikliniai moduliai",
            "Sąsaja su žmogaus moduliai",
            "Ratai",
            "Tranzistoriai",
            "Mikrovaldikliai",
            "Valdymo ir stiprinimo moduliai",
            "Varikliai",
            "Diodai",
            "LED",
            "Komunikacijos moduliai"});
            this.Prideti_ComboBox.Location = new System.Drawing.Point(34, 170);
            this.Prideti_ComboBox.Name = "Prideti_ComboBox";
            this.Prideti_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.Prideti_ComboBox.TabIndex = 33;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(178, 117);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(49, 17);
            this.checkBox2.TabIndex = 32;
            this.checkBox2.Text = "Išimti";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(34, 117);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(55, 17);
            this.checkBox1.TabIndex = 31;
            this.checkBox1.Text = "Pridėti";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(631, 24);
            this.menuStrip1.TabIndex = 47;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(631, 407);
            this.Controls.Add(this.Ataskaita1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NameLastName_txt);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Vardas_Pavarde_lbl);
            this.Controls.Add(this.addNewUsers_btn);
            this.Controls.Add(this.DataIsimtu);
            this.Controls.Add(this.DataPridetu);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Paieska_btn);
            this.Controls.Add(this.Info_Btn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Prideti_TextBox);
            this.Controls.Add(this.Save_Btn);
            this.Controls.Add(this.Isimti_TextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Isimti_ComboBox);
            this.Controls.Add(this.Prideti_ComboBox);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Pagrindinis langas";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Ataskaita1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameLastName_txt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Vardas_Pavarde_lbl;
        private System.Windows.Forms.Button addNewUsers_btn;
        private System.Windows.Forms.DateTimePicker DataIsimtu;
        private System.Windows.Forms.DateTimePicker DataPridetu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Paieska_btn;
        private System.Windows.Forms.Button Info_Btn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Prideti_TextBox;
        private System.Windows.Forms.Button Save_Btn;
        private System.Windows.Forms.TextBox Isimti_TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Isimti_ComboBox;
        private System.Windows.Forms.ComboBox Prideti_ComboBox;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
    }
}