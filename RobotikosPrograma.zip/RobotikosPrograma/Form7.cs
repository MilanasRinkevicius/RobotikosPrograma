﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RobotikosPrograma
{
    public partial class Form7 : Form
    {
        string connectionString = @"C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf"; //databazes kintamasis
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //atidaroma databaze
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + connectionString + ";Integrated Security=True");
            con.Open(); 

            //sudaromos uzklausos databazei
            string query1, query2;

            query1 = "SELECT IvestiIstekliai, SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIvestu <= '"+ dateIki.Text + "' AND DataIvestu >= '" + dateNuo.Text + "' AND VardasIrPavarde = '"+ VardasIeskoti_txt.Text + "' GROUP BY IvestiIstekliai";
            query2 = "SELECT IsimtiIstekliai, SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu <= '" + dateIki.Text + "' AND DataIsimtu >= '" + dateNuo.Text + "' AND VardasIrPavarde = '" + VardasIeskoti_txt.Text + "' GROUP BY IsimtiIstekliai";
             
            
            //uzklausos vykdomos
            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Parameters.AddWithValue("@Vardas", VardasIeskoti_txt.Text);
            DataTable ss = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter(cmd1);
            data.Fill(ss);
            dataGridView1.DataSource = ss;

            SqlCommand command = new SqlCommand(query2, con);
            cmd1.Parameters.AddWithValue("@Vardas", VardasIeskoti_txt.Text);
            DataTable sss = new DataTable();
            SqlDataAdapter datas = new SqlDataAdapter(command);
            datas.Fill(sss);
            dataGridView2.DataSource = sss;

            //uzdaroma databaze
            con.Close();
        }

        private void goBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //grizti i pagrindini langa
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        }

        private void Form7_FormClosed(object sender, FormClosedEventArgs e)
        {
            //uzdaryti programa
            Application.Exit();
        }
    }
}
