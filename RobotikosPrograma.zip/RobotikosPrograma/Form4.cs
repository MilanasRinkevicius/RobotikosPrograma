﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace RobotikosPrograma
{
    public partial class Form4 : Form
    {
        MyConnection db = new MyConnection();
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                using (db.con)
                {
                    //tikrinti ar atitikantys slaptazodziai ir jei taip tai pakeisti slaptazodi
                    if (textBox2.Text == textBox3.Text && textBox1.Text != "" && textBox2.Text != "")
                    {
                        db.con.Open();
                        SqlCommand cmd = new SqlCommand("UPDATE LogIn SET Password = '" + textBox3.Text + "' Where Username = '" + textBox4.Text + "' AND Password = '" + textBox1.Text + "'", db.con);
                        cmd.ExecuteNonQuery();
                        db.con.Close();
                        MessageBox.Show("Vartotojo slaptažodis sėkmingai pakeistas! Iš naujo prisijunkite");
                        Form1 d = new Form1();
                        d.Show();
                        this.Hide();
                    }
                    else if (textBox2.Text == "" && textBox3.Text == "")
                    {
                        MessageBox.Show("Neįvesti jokie slaptažodžiai");
                    }
                    else if (textBox2.Text != textBox3.Text)
                    {
                        MessageBox.Show("Įvesti slaptažodžiai nesutampa");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void GoBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //grizti atgal i prisijungimo langa
            Form1 d = new Form1();
            d.Show();
            this.Hide();
        }
    }
}
