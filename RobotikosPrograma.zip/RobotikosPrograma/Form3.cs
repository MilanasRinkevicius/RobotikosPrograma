﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace RobotikosPrograma
{
    public partial class Form3 : Form
    {
        
        string location = Path.GetFullPath("Database1.mdf");
        SqlCommand cmd;
        
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
        SqlDataAdapter da;
        public Form3()
        {
            InitializeComponent();
        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            //tikrinti ar ivestas vardas slapyvardis ir slaptazodis, jei ivesti visi vykdyti uzklausa
            con.Open();
            if (Vardas_txt.Text != "" && Username_txt.Text != "" && Password_txt.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO LogIn (Name, Username, Password, Type) VALUES (@Name, @Username, @Password, @Type)", con);
                cmd.Parameters.AddWithValue("@Name", Vardas_txt.Text);
                cmd.Parameters.AddWithValue("@Username", Username_txt.Text);
                cmd.Parameters.AddWithValue("@Password", Password_txt.Text);
                cmd.Parameters.AddWithValue("@Type", "User");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Vartotojas sėkmingai pridėtas");
                con.Close();
            }
            else if (Vardas_txt.Text == "" || Username_txt.Text == "" || Password_txt.Text == "")
            {
                MessageBox.Show("Ne visi duomenys įvesti");
                con.Close();
            }
        }

        private void Delete_btn_Click(object sender, EventArgs e)
        {
            //tikrinti kad trintu ne administratoriu
            con.Open();
            if (Delete_txt.Text != "Milanas Rinkevicius" && Delete_txt.Text != "")
            {
                cmd = new SqlCommand("DELETE FROM LogIn WHERE Name = @name", con);
                cmd.Parameters.AddWithValue("@name", Delete_txt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Ištrinta sekmingai");
                con.Close();
            }
            else if (Delete_txt.Text == "Milanas Rinkevicius")
            {
                MessageBox.Show("Negalima ištrinti admin teisių turinčių vartotojų");
                con.Close();
            }
            else if (Delete_txt.Text == "")
            {
                MessageBox.Show("Norint ištrinti reikia įvesti kieno duomenis ištrinti");
                con.Close();
            }
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void goBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //grizti i pagrindini langa
            Form2 d = new Form2();
            d.Show();
            this.Hide();
        }
        void GridFill()
        {
            //isvesti lentele istekliu
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
            using (con)
            {
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("IstekliaiVisi", con);
                DataTable datatable = new DataTable();
                sqlDa.Fill(datatable);
                dataGridView1.DataSource = datatable;
                con.Close();
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //isvesti lentele vardo, slapyvardzio ir slaptazodzio
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
            con.Open();

            string query1;

            query1 = "SELECT Name, Username, Password FROM LogIn";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            DataTable ss = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter(cmd1);
            data.Fill(ss);
            dataGridView1.DataSource = ss;

            con.Close();
        }

        //saugoti naujus slaptazodzius
        private void SaveNewUserPass_btn_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
            con.Open();

            using (con)
            {
                if (NewPassword_txt.Text == NewPasswordRepeat_txt.Text && NewPassword_txt.Text != "" && textBox1.Text != "")
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE LogIn SET Password = '" + NewPassword_txt.Text + "', Username = '"+ NewUsername_txt.Text +"' Where Name = '" + textBox1.Text + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Vartotojo slaptažodis sėkmingai pakeistas!");
                    Form1 d = new Form1();
                    d.Show();
                    this.Hide();
                }
                else if (NewPassword_txt.Text == "" && NewPasswordRepeat_txt.Text == "")
                {
                    MessageBox.Show("Neįvesti jokie slaptažodžiai");
                }
                else if (NewPassword_txt.Text != NewPasswordRepeat_txt.Text)
                {
                    MessageBox.Show("Įvesti slaptažodžiai nesutampa");
                }
            }
        }
    }
}
