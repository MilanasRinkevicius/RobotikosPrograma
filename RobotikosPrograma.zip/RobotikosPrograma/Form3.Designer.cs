﻿
namespace RobotikosPrograma
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label9 = new System.Windows.Forms.Label();
            this.Delete_btn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Delete_txt = new System.Windows.Forms.TextBox();
            this.SaveNewUserPass_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.NewUsername_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NewPasswordRepeat_txt = new System.Windows.Forms.TextBox();
            this.NewPassword_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Username_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Vardas_txt = new System.Windows.Forms.TextBox();
            this.Save_btn = new System.Windows.Forms.Button();
            this.Password_lbl = new System.Windows.Forms.Label();
            this.Vardas_lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.goBackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label9.Location = new System.Drawing.Point(21, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(257, 25);
            this.label9.TabIndex = 47;
            this.label9.Text = "Ištrinti vartotojų duomenis";
            // 
            // Delete_btn
            // 
            this.Delete_btn.Location = new System.Drawing.Point(161, 288);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.Size = new System.Drawing.Size(100, 39);
            this.Delete_btn.TabIndex = 46;
            this.Delete_btn.Text = "Ištrinti";
            this.Delete_btn.UseVisualStyleBackColor = true;
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 13);
            this.label8.TabIndex = 45;
            this.label8.Text = "Kurį vartotoją ištrinti?";
            // 
            // Delete_txt
            // 
            this.Delete_txt.Location = new System.Drawing.Point(133, 239);
            this.Delete_txt.Name = "Delete_txt";
            this.Delete_txt.Size = new System.Drawing.Size(128, 20);
            this.Delete_txt.TabIndex = 44;
            // 
            // SaveNewUserPass_btn
            // 
            this.SaveNewUserPass_btn.Location = new System.Drawing.Point(519, 464);
            this.SaveNewUserPass_btn.Name = "SaveNewUserPass_btn";
            this.SaveNewUserPass_btn.Size = new System.Drawing.Size(100, 39);
            this.SaveNewUserPass_btn.TabIndex = 43;
            this.SaveNewUserPass_btn.Text = "Išsaugoti";
            this.SaveNewUserPass_btn.UseVisualStyleBackColor = true;
            this.SaveNewUserPass_btn.Click += new System.EventHandler(this.SaveNewUserPass_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(333, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 13);
            this.label7.TabIndex = 42;
            this.label7.Text = "Naujas vartotojo vardas";
            // 
            // NewUsername_txt
            // 
            this.NewUsername_txt.Location = new System.Drawing.Point(458, 298);
            this.NewUsername_txt.Name = "NewUsername_txt";
            this.NewUsername_txt.Size = new System.Drawing.Size(161, 20);
            this.NewUsername_txt.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(353, 419);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "Pakartoti slaptažodį";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(357, 360);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 39;
            this.label6.Text = "Naujas slaptažodis";
            // 
            // NewPasswordRepeat_txt
            // 
            this.NewPasswordRepeat_txt.Location = new System.Drawing.Point(458, 416);
            this.NewPasswordRepeat_txt.Name = "NewPasswordRepeat_txt";
            this.NewPasswordRepeat_txt.Size = new System.Drawing.Size(161, 20);
            this.NewPasswordRepeat_txt.TabIndex = 38;
            // 
            // NewPassword_txt
            // 
            this.NewPassword_txt.Location = new System.Drawing.Point(458, 357);
            this.NewPassword_txt.Name = "NewPassword_txt";
            this.NewPassword_txt.Size = new System.Drawing.Size(161, 20);
            this.NewPassword_txt.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(296, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "Kurio vartotojo duomenis keisti?";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(458, 239);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(161, 20);
            this.textBox1.TabIndex = 35;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(658, 239);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(243, 241);
            this.dataGridView1.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label3.Location = new System.Drawing.Point(498, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(298, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Redaguoti vartotojų duomenis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.Location = new System.Drawing.Point(367, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 25);
            this.label2.TabIndex = 32;
            this.label2.Text = "Pridėti vartotojus";
            // 
            // Username_txt
            // 
            this.Username_txt.Location = new System.Drawing.Point(372, 104);
            this.Username_txt.Name = "Username_txt";
            this.Username_txt.Size = new System.Drawing.Size(100, 20);
            this.Username_txt.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(379, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Vartotojo vardas";
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(519, 104);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.Size = new System.Drawing.Size(100, 20);
            this.Password_txt.TabIndex = 29;
            // 
            // Vardas_txt
            // 
            this.Vardas_txt.Location = new System.Drawing.Point(176, 104);
            this.Vardas_txt.Name = "Vardas_txt";
            this.Vardas_txt.Size = new System.Drawing.Size(152, 20);
            this.Vardas_txt.TabIndex = 28;
            // 
            // Save_btn
            // 
            this.Save_btn.Location = new System.Drawing.Point(676, 94);
            this.Save_btn.Name = "Save_btn";
            this.Save_btn.Size = new System.Drawing.Size(100, 39);
            this.Save_btn.TabIndex = 27;
            this.Save_btn.Text = "Išsaugoti";
            this.Save_btn.UseVisualStyleBackColor = true;
            this.Save_btn.Click += new System.EventHandler(this.Save_btn_Click);
            // 
            // Password_lbl
            // 
            this.Password_lbl.AutoSize = true;
            this.Password_lbl.Location = new System.Drawing.Point(539, 88);
            this.Password_lbl.Name = "Password_lbl";
            this.Password_lbl.Size = new System.Drawing.Size(61, 13);
            this.Password_lbl.TabIndex = 26;
            this.Password_lbl.Text = "Slaptažodis";
            // 
            // Vardas_lbl
            // 
            this.Vardas_lbl.AutoSize = true;
            this.Vardas_lbl.Location = new System.Drawing.Point(186, 88);
            this.Vardas_lbl.Name = "Vardas_lbl";
            this.Vardas_lbl.Size = new System.Drawing.Size(131, 13);
            this.Vardas_lbl.TabIndex = 25;
            this.Vardas_lbl.Text = "Mokinio Vardas ir Pavardė";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goBackToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(926, 24);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // goBackToolStripMenuItem
            // 
            this.goBackToolStripMenuItem.Name = "goBackToolStripMenuItem";
            this.goBackToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.goBackToolStripMenuItem.Text = "Grįžti";
            this.goBackToolStripMenuItem.Click += new System.EventHandler(this.goBackToolStripMenuItem_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(926, 547);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Delete_btn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Delete_txt);
            this.Controls.Add(this.SaveNewUserPass_btn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NewUsername_txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NewPasswordRepeat_txt);
            this.Controls.Add(this.NewPassword_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Username_txt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Password_txt);
            this.Controls.Add(this.Vardas_txt);
            this.Controls.Add(this.Save_btn);
            this.Controls.Add(this.Password_lbl);
            this.Controls.Add(this.Vardas_lbl);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "vartotojų duomenys";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Delete_txt;
        private System.Windows.Forms.Button SaveNewUserPass_btn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox NewUsername_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NewPasswordRepeat_txt;
        private System.Windows.Forms.TextBox NewPassword_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Username_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Vardas_txt;
        private System.Windows.Forms.Button Save_btn;
        private System.Windows.Forms.Label Password_lbl;
        private System.Windows.Forms.Label Vardas_lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem goBackToolStripMenuItem;
    }
}