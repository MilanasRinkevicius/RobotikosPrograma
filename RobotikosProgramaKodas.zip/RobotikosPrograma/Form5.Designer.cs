﻿
namespace RobotikosPrograma
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Delete_btn = new System.Windows.Forms.Button();
            this.DeleteIstklPVD_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Edit_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.RedagKritIst_txt = new System.Windows.Forms.TextBox();
            this.RedagIsteklPVD_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Save_Btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SaugKritIst_txt = new System.Windows.Forms.TextBox();
            this.SaugIsteklioPvd_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.GoBackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(448, 235);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(276, 199);
            this.dataGridView1.TabIndex = 43;
            // 
            // Delete_btn
            // 
            this.Delete_btn.Location = new System.Drawing.Point(253, 258);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.Size = new System.Drawing.Size(75, 34);
            this.Delete_btn.TabIndex = 42;
            this.Delete_btn.Text = "Ištrinti";
            this.Delete_btn.UseVisualStyleBackColor = true;
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // DeleteIstklPVD_txt
            // 
            this.DeleteIstklPVD_txt.Location = new System.Drawing.Point(57, 266);
            this.DeleteIstklPVD_txt.Name = "DeleteIstklPVD_txt";
            this.DeleteIstklPVD_txt.Size = new System.Drawing.Size(100, 20);
            this.DeleteIstklPVD_txt.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 13);
            this.label6.TabIndex = 40;
            this.label6.Text = "Ištrinamo išteklio pavadinimas";
            // 
            // Edit_btn
            // 
            this.Edit_btn.Location = new System.Drawing.Point(649, 138);
            this.Edit_btn.Name = "Edit_btn";
            this.Edit_btn.Size = new System.Drawing.Size(75, 34);
            this.Edit_btn.TabIndex = 39;
            this.Edit_btn.Text = "Redaguoti";
            this.Edit_btn.UseVisualStyleBackColor = true;
            this.Edit_btn.Click += new System.EventHandler(this.Edit_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(605, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Redaguoti kritinį išteklio kiekį";
            // 
            // RedagKritIst_txt
            // 
            this.RedagKritIst_txt.Location = new System.Drawing.Point(624, 91);
            this.RedagKritIst_txt.Name = "RedagKritIst_txt";
            this.RedagKritIst_txt.Size = new System.Drawing.Size(100, 20);
            this.RedagKritIst_txt.TabIndex = 37;
            // 
            // RedagIsteklPVD_txt
            // 
            this.RedagIsteklPVD_txt.Location = new System.Drawing.Point(448, 91);
            this.RedagIsteklPVD_txt.Name = "RedagIsteklPVD_txt";
            this.RedagIsteklPVD_txt.Size = new System.Drawing.Size(100, 20);
            this.RedagIsteklPVD_txt.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(411, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Redaguojamo išteklio pavadinimas";
            // 
            // Save_Btn
            // 
            this.Save_Btn.Location = new System.Drawing.Point(253, 138);
            this.Save_Btn.Name = "Save_Btn";
            this.Save_Btn.Size = new System.Drawing.Size(75, 34);
            this.Save_Btn.TabIndex = 34;
            this.Save_Btn.Text = "Saugoti";
            this.Save_Btn.UseVisualStyleBackColor = true;
            this.Save_Btn.Click += new System.EventHandler(this.Save_Btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(216, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Pridėti kritinį išteklio kiekį";
            // 
            // SaugKritIst_txt
            // 
            this.SaugKritIst_txt.Location = new System.Drawing.Point(228, 91);
            this.SaugKritIst_txt.Name = "SaugKritIst_txt";
            this.SaugKritIst_txt.Size = new System.Drawing.Size(100, 20);
            this.SaugKritIst_txt.TabIndex = 32;
            // 
            // SaugIsteklioPvd_txt
            // 
            this.SaugIsteklioPvd_txt.Location = new System.Drawing.Point(52, 91);
            this.SaugIsteklioPvd_txt.Name = "SaugIsteklioPvd_txt";
            this.SaugIsteklioPvd_txt.Size = new System.Drawing.Size(100, 20);
            this.SaugIsteklioPvd_txt.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Pridedamo išteklio pavadinimas";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GoBackToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 44;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // GoBackToolStripMenuItem
            // 
            this.GoBackToolStripMenuItem.Name = "GoBackToolStripMenuItem";
            this.GoBackToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.GoBackToolStripMenuItem.Text = "Grįžti";
            this.GoBackToolStripMenuItem.Click += new System.EventHandler(this.GoBackToolStripMenuItem_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Delete_btn);
            this.Controls.Add(this.DeleteIstklPVD_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Edit_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RedagKritIst_txt);
            this.Controls.Add(this.RedagIsteklPVD_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Save_Btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SaugKritIst_txt);
            this.Controls.Add(this.SaugIsteklioPvd_txt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "įšteklių duomenys";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form5_FormClosed);
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.TextBox DeleteIstklPVD_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Edit_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox RedagKritIst_txt;
        private System.Windows.Forms.TextBox RedagIsteklPVD_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Save_Btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SaugKritIst_txt;
        private System.Windows.Forms.TextBox SaugIsteklioPvd_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem GoBackToolStripMenuItem;
    }
}