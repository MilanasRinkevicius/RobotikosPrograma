﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RobotikosPrograma
{
    public partial class Form1 : Form
    {
        public static string SetValueForText1 = "";
        MyConnection db = new MyConnection();

        public Form1()
        {
            InitializeComponent();
        }

        private void LogIn_btn_Click(object sender, EventArgs e)
        {
            try
            {
                using (db.con)
                {
                    SqlCommand cmd = new SqlCommand("Procedure", db.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    db.con.Open();
                    cmd.Parameters.AddWithValue("@uname", UsernameTextbox.Text);
                    cmd.Parameters.AddWithValue("@upass", PasswordTextbox.Text);
                    SqlDataReader rd = cmd.ExecuteReader();
                    if (rd.HasRows)
                    {
                        rd.Read();
                        //prisijungia su admin teisemis
                        if (rd[4].ToString() == "Admin")
                        {
                            MyConnection.type = "A";
                            SetValueForText1 = rd[1].ToString();
                        }
                        //prisijungia su varototojo teisemis
                        else if (rd[4].ToString() == "User")
                        {
                            MyConnection.type = "U";
                            SetValueForText1 = rd[1].ToString();
                        }
                        Form2 d = new Form2();
                        d.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Klaidingas vartotojo vardas ar slaptažodis");
                        UsernameTextbox.Clear();
                        PasswordTextbox.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void ChangePassword_btn_Click(object sender, EventArgs e)
        {
            //atidaro keisti slaptazodi langa
            Form4 d = new Form4();
            d.Show();
            this.Hide();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
