﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RobotikosPrograma
{
    public partial class Form5 : Form
    {
        //atidaroma databaze
        SqlCommand cmd;
        SqlConnection con; 
        SqlDataAdapter da;
        string connectionString = @"C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf";
        public Form5()
        {
            InitializeComponent();
        }


        //sukurti naujus isteklius databazeje
        private void Save_Btn_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename="+ connectionString + ";Integrated Security=True");

            con.Open();
            if (SaugIsteklioPvd_txt.Text != "" && SaugKritIst_txt.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO Istekliai (IsteklioPVD, KritinisKiek) VALUES (@IsteklioPVD, @Kritiniskiekis)", con);
                cmd.Parameters.AddWithValue("@IsteklioPVD", SaugIsteklioPvd_txt.Text);
                cmd.Parameters.AddWithValue("@Kritiniskiekis", SaugKritIst_txt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Išteklis sėkmingai pridėtas");
                con.Close();
            }
            else if (SaugIsteklioPvd_txt.Text == "" || SaugKritIst_txt.Text == "")
            {
                MessageBox.Show("Ne visi duomenys įvesti");
                con.Close();
            }
        }
        
        //uzdaryti programa
        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        //istrinti isteklius
        private void Delete_btn_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + connectionString + ";Integrated Security=True");
            con.Open();
            if (DeleteIstklPVD_txt.Text != "")
            {
                cmd = new SqlCommand("DELETE FROM Istekliai WHERE IsteklioPVD = @IsteklioPVD", con);
                cmd.Parameters.AddWithValue("@IsteklioPVD", DeleteIstklPVD_txt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Ištrinta sekmingai");
                GridFill();
                con.Close();
            }
            else if (DeleteIstklPVD_txt.Text == "")
            {
                MessageBox.Show("Ne visi duomenys įvesti");
                con.Close();
            }
        }

        //isvesti isteklius i lentele
        void GridFill()
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + connectionString + ";Integrated Security=True");
            using (con)
            {
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("IstekliaiVisi", con);
                DataTable datatable = new DataTable();
                sqlDa.Fill(datatable);
                dataGridView1.DataSource = datatable;
                con.Close();
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            GridFill();
        }

        //tvarkyti isteklius
        private void Edit_btn_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + connectionString + ";Integrated Security=True");
            con.Open();
            if (RedagKritIst_txt.Text != "" && RedagIsteklPVD_txt.Text != "")
            {
                cmd = new SqlCommand("UPDATE Istekliai SET KritinisKiek=@Kritiniskiekis WHERE IsteklioPVD=@IsteklioPVD", con);
                cmd.Parameters.AddWithValue("@Kritiniskiekis", RedagKritIst_txt.Text);
                cmd.Parameters.AddWithValue("@IsteklioPVD", RedagIsteklPVD_txt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sėkmingai redaguota");
                GridFill();
                con.Close();
            }
            else if (RedagKritIst_txt.Text == "" || RedagIsteklPVD_txt.Text == "")
            {
                MessageBox.Show("Ne visi duomenys įvesti");
                con.Close();
            }
        }

        private void GoBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 d = new Form2();
            d.Show();
            this.Hide();
        }
    }
}
