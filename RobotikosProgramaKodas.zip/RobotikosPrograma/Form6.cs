﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using ClosedXML;
using DocumentFormat.OpenXml;

namespace RobotikosPrograma
{
    public partial class Form6 : Form
    {
        //atidaroma databaze
        MyConnection db;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
        public Form6()
        {
            InitializeComponent();
        }
        private void Update_Click(object sender, EventArgs e)
        {
            con.Open();

            //sudaromos uzklausos
            string query1, query2, query3, query4, query5, query6;
            int PirmasStulp = 0, AntrasStulp = 0, TreciasStulp = 0, KetvirtasStulp = 0, PenktasStulp = 0, SestasStulp = 0;

            query1 = "SELECT IvestiIstekliai, SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIvestu <= @Data GROUP BY IvestiIstekliai";
            query2 = "SELECT IsimtiIstekliai, SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu <= @Data GROUP BY IsimtiIstekliai";
            query3 = "SELECT SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIsimtu >= @Data AND DataIvestu <= @Data1";
            query4 = "SELECT SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu >= @Data AND DataIvestu <= @Data1";
            query5 = "SELECT SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIvestu <= @Data";
            query6 = "SELECT SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu <= @Data";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
            DataTable ss = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter(cmd1);
            data.Fill(ss);
            dataGridView1.DataSource = ss;
            
            //uzdaroma databaze
            con.Close();

            //databaze atidaroma kitai uzklausai
            con.Open();

            SqlCommand command = new SqlCommand(query2, con);
            command.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
            DataTable sss = new DataTable();
            SqlDataAdapter datas = new SqlDataAdapter(command);
            datas.Fill(sss);
            dataGridView2.DataSource = sss;

            con.Close();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            //tikrinti ar yra spausdintuvai
            if (PrinterSettings.InstalledPrinters.Count <= 0)
            {
                MessageBox.Show("Printer not found!");
                return;
            }

            //gauti visus galimus spausdintuvus ir prideti juos i pasirinkimo laukeli 
            foreach (String printer in PrinterSettings.InstalledPrinters)
            {
                printersList.Items.Add(printer.ToString());
            }

            //atidaryti databaze
            con.Open();

            //sudaromos uzklausos
            string query1, query2, query3, query4, query5, query6;

            query1 = "SELECT IvestiIstekliai, SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIvestu <= @Data GROUP BY IvestiIstekliai";
            query2 = "SELECT IsimtiIstekliai, SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu <= @Data GROUP BY IsimtiIstekliai";

            //uzklausos vykdomos
            SqlCommand cmd1 = new SqlCommand(query1, con);
            cmd1.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
            DataTable ss = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter(cmd1);
            data.Fill(ss);
            dataGridView1.DataSource = ss;

            con.Close();

            con.Open();

            SqlCommand command = new SqlCommand(query2, con);
            command.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
            DataTable sss = new DataTable();
            SqlDataAdapter datas = new SqlDataAdapter(command);
            datas.Fill(sss);
            dataGridView2.DataSource = sss;

            con.Close();

            con.Open();

            SqlCommand cmd8 = new SqlCommand("SELECT IsteklioPavadinimas, IsteklioKiekis FROM Skirt", con);
            DataTable gg = new DataTable();
            SqlDataAdapter datu = new SqlDataAdapter(cmd8);
            datu.Fill(gg);
            dataGridView4.DataSource = gg;

            con.Close();

            con.Open();

            SqlCommand cmd = new SqlCommand("Select * from Istekliai", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();

            con.Close();

            comboBox1.DataSource = ds.Tables[0];
            comboBox1.DisplayMember = "IsteklioPVD";
            comboBox1.ValueMember = "Id";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //atidaroma databaze
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");

            con1.Open();
            //vykdomos uzklausos
            SqlCommand cmd6 = new SqlCommand("SELECT IsteklioPavadinimas, IsteklioKiekis FROM Skirt", con1);
            DataTable dt = new DataTable();
            SqlDataAdapter datus = new SqlDataAdapter(cmd6);
            datus.Fill(dt);
            //sukurti excel faila
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Excel Workbook|*.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (ClosedXML.Excel.XLWorkbook workbook = new ClosedXML.Excel.XLWorkbook())
                        {
                            workbook.Worksheets.Add(dt, "worksheet1");
                            workbook.SaveAs(sfd.FileName);
                        }
                        MessageBox.Show("sekmingai issaugota", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            con1.Close();
        }

        private void LoadBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\RobotikosPrograma\RobotikosPrograma\Database1.mdf;Integrated Security=True");
            con1.Open();

            //sukurti uzklausa ir ja vykdyti
            string space = "";
            SqlCommand cmd = new SqlCommand("DELETE FROM Skirt WHERE IsteklioPavadinimas !='" + space + "'", con1);
            DataTable rr = new DataTable();
            SqlDataAdapter rt = new SqlDataAdapter(cmd);
            rt.Fill(rr);
            dataGridView4.DataSource = rr;

            con1.Close();
            //sukurti nauja uzklausa
            string query5 = "INSERT INTO Skirt VALUES(@para1, @para2)";

            for (int i = 0; i < comboBox1.Items.Count; i++)
            {
                string value = comboBox1.GetItemText(comboBox1.Items[i]);

                string query3, query4, query2;
                int TreciasStulp = 0, KetvirtasStulp = 0, penktasStulp = 0;
                query3 = "SELECT SUM(IvestuIstekliuKiek) FROM Robotika WHERE DataIvestu <= @Data AND IvestiIstekliai='" + value + "'";
                query4 = "SELECT SUM(IsimtuIstekliuKiek) FROM Robotika WHERE DataIsimtu <= @Data AND IsimtiIstekliai='" + value + "'";
                query2 = "SELECT KritinisKiek FROM Istekliai WHERE IsteklioPVD ='" + value + "'";

                con1.Open();

                //vykdyti uzklausa
                SqlCommand cmd3 = new SqlCommand(query3, con1);
                cmd3.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
                SqlDataReader rd3 = cmd3.ExecuteReader();
                if (rd3.HasRows)
                {
                    rd3.Read(); // read first row
                    TreciasStulp = rd3.GetInt32(0);
                    rd3.Close();
                }
                else rd3.Close();

                SqlCommand cmd4 = new SqlCommand(query4, con1);
                cmd4.Parameters.AddWithValue("@Data", dateTimePicker1.Value);
                SqlDataReader rd4 = cmd4.ExecuteReader();
                if (rd4.HasRows)
                {
                    rd4.Read(); // read first row

                    if (rd4.IsDBNull(0))
                        KetvirtasStulp = 0;
                    else if (rd4.GetInt32(0) >= 0)
                        KetvirtasStulp = rd4.GetInt32(0);
                    rd4.Close();
                }
                else rd4.Close();



                SqlCommand cmd2 = new SqlCommand(query2, con1);
                SqlDataReader rd = cmd2.ExecuteReader();
                if (rd.HasRows)
                {
                    rd.Read();
                    penktasStulp = rd.GetInt32(0);
                    rd.Close();
                }
                if ((TreciasStulp - KetvirtasStulp) <= penktasStulp)
                {
                    MessageBox.Show("nepakanka '" + value + "' nupirkite daugiau");
                }

                con1.Close();

                con1.Open();

                SqlCommand cmd5 = new SqlCommand(query5, con1);
                cmd5.Parameters.AddWithValue("@para1", value);
                cmd5.Parameters.AddWithValue("@para2", TreciasStulp - KetvirtasStulp);


                DataTable ff = new DataTable();
                SqlDataAdapter datu = new SqlDataAdapter(cmd5);
                datu.Fill(ff);
                dataGridView4.DataSource = ff;

                con1.Close();
            }

            con1.Open();
            //sukurti uzklausa ir ja vykdyti
            SqlCommand cmd7 = new SqlCommand("SELECT IsteklioPavadinimas, IsteklioKiekis FROM Skirt", con1);
            DataTable gg = new DataTable();
            SqlDataAdapter datus = new SqlDataAdapter(cmd7);
            datus.Fill(gg);
            dataGridView4.DataSource = gg;

            con1.Close();
        }

        private void ToCSV_btn_Click(object sender, EventArgs e)
        {
            //spausdinti
            PrintDocument pd = new PrintDocument();
            pd.PrinterSettings.PrinterName = printersList.SelectedItem.ToString();
            pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);
            pd.Print();
        }
        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            //gauti grafini objekta
            Graphics g = ev.Graphics;
            //sukurti Arial stiliu 16 didzio raidemis
            Font font = new Font("Arial", 10);
            //Create a solid brush with black color  
            SolidBrush brush = new SolidBrush(Color.Black);
            
            //piesti data;
            int i = 100;
            int y = 30;

            g.DrawString("Panevėžio Juozo Balčikonio gimnazijos \n\n Robotikos laboratorijos \n\n Išteklių \n\n Inventorizacijos aprašas \n\n" +
                "Inventorizacijos atlikimo Data " + dateTimePicker1.Text + "\n", font, brush,
                new Rectangle(i, y, 400, 400));
            y += 200;
            g.DrawString("Išteklio pavadinimas:         Likutis",
                font, brush, new Rectangle(i, y, 400, 400));
            y += 50;
            foreach (DataGridViewRow row in dataGridView4.Rows)
            {
                g.DrawString(row.Cells[0].Value + "   ----   " + row.Cells[1].Value,
                font, brush,
                new Rectangle(i, y, 400, y));
                y += 30;
            }
            g.DrawString("Inventorizaciją atliko \n " + Form1.SetValueForText1,
                font, brush, new Rectangle(i, y, 400, y));
        }

        private void Form6_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void goBackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //grizti i pagrindini langa
            Form2 F = new Form2();
            F.Show();
            this.Hide();
        }
    }
}
